// Remplacez ces valeurs par celles de votre projet Firebase
const FIREBASE_CONFIG = {
  apiKey: "VOTRE_APIKEY",
  authDomain: "VOTRE_AUTHDOMAIN",
  databaseURL: "VOTRE_DATABASE_URL",
  projectId: "VOTRE_PROJECTID",
  storageBucket: "VOTRE_STORAGEBUCKET",
  messagingSenderId: "VOTRE_MESSAGING_SENDER_ID",
  appId: "VOTRE_APPID",
};

export default FIREBASE_CONFIG;
